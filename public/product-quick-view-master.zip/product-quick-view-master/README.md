Product Quick View
=========

A 'product quick view' modal window, animated using CSS3 and Velocity.js, that provides the user a quick access to the main product information.

[Article on CodyHouse](http://codyhouse.co/gem/css-product-quick-view/)

[Demo](http://codyhouse.co/demo/product-quick-view/index.html)
 
[Terms](http://codyhouse.co/terms/)
