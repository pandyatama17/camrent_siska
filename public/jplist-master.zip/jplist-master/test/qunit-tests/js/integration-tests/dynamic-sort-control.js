var jplist = jQuery.fn.jplist;

QUnit.module('Integration Test: Dynamic Sort Control');