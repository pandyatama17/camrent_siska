/**
* deep links
*/
QUnit.module('Unit Test: Deep Links');
	
/**
* getUniqueControls - sort
*/
QUnit.test('getUniqueControls', function(assert){

	
	assert.ok(true);
	//assert.ok(resultDataview.length == 1, 'Array should have 1 item')
});
