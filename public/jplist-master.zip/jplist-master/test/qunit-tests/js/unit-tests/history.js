/**
* history
*/
QUnit.module('Unit Test: History');
	
/**
* test 1
*/
QUnit.test('test 1', function(assert){

	
	assert.ok(true);
	//assert.ok(resultDataview.length == 1, 'Array should have 1 item')
});
