<?php
	class FilterResultModel{
		
		/**
		* query part
		*/
		public $query;
		
		/**
		* prepared param
		*/
		public $param;
	}
?>