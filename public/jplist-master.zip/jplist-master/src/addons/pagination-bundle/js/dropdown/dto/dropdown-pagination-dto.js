(function(){
	'use strict';		
	
	/** 
	* Dropdown Pagination Model
	* @constructor
	* @param {string} number
	*/
	jQuery.fn.jplist.controls.DropdownPaginationDTO = function(number){
		
		return {
			number: number
		};
	};	
		
})();

