(function(){
	'use strict';		
	
	/** 
	* Bootstrap Dropdown Pagination Model
	* @constructor
	* @param {string} number
	*/
	jQuery.fn.jplist.controls.BootstrapDropdownPaginationDTO = function(number){
		
		return {
			number: number
		};
	};	
		
})();

