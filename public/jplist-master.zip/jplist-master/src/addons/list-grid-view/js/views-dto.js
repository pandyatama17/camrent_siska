(function(){
	'use strict';		
	
	/** 
	* Views Model
	* @constructor
	* @param {string} viewName
	*/
	jQuery.fn.jplist.controls.ViewsDTO = function(viewName){
		this.view = viewName;
	};	
		
})();

